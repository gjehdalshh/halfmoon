function moveDetail(i_product,i_user){
	location.href = '/sale/detail?i_product=' + i_product + '&i_user=' + i_user;
}