package com.halfmoon.market.model;

public class LogEntity {

	private int i_log;
	private int i_product;
	private int i_user_sale;
	private int i_user_buy;
	private int r_dt;
	
	public int getI_log() {
		return i_log;
	}
	public void setI_log(int i_log) {
		this.i_log = i_log;
	}
	public int getI_product() {
		return i_product;
	}
	public void setI_product(int i_product) {
		this.i_product = i_product;
	}
	public int getI_user_sale() {
		return i_user_sale;
	}
	public void setI_user_sale(int i_user_sale) {
		this.i_user_sale = i_user_sale;
	}
	public int getI_user_buy() {
		return i_user_buy;
	}
	public void setI_user_buy(int i_user_buy) {
		this.i_user_buy = i_user_buy;
	}
	public int getR_dt() {
		return r_dt;
	}
	public void setR_dt(int r_dt) {
		this.r_dt = r_dt;
	}
}
