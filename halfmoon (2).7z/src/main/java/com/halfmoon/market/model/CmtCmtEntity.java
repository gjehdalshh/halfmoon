package com.halfmoon.market.model;

public class CmtCmtEntity {
	
	private int i_cmt_cmt;
	private int i_cmt;
	private String ctnt;
	private String r_dt;
	private String i_product;
	
	public int getI_cmt_cmt() {
		return i_cmt_cmt;
	}
	public void setI_cmt_cmt(int i_cmt_cmt) {
		this.i_cmt_cmt = i_cmt_cmt;
	}
	public int getI_cmt() {
		return i_cmt;
	}
	public void setI_cmt(int i_cmt) {
		this.i_cmt = i_cmt;
	}
	public String getCtnt() {
		return ctnt;
	}
	public void setCtnt(String ctnt) {
		this.ctnt = ctnt;
	}
	public String getR_dt() {
		return r_dt;
	}
	public void setR_dt(String r_dt) {
		this.r_dt = r_dt;
	}
	public String getI_product() {
		return i_product;
	}
	public void setI_product(String i_product) {
		this.i_product = i_product;
	}
}
