package com.halfmoon.market.model;

public class ProductTypeEntity {
	
	private int i_product_type;
	private String type_title;
	
	public int getI_product_type() {
		return i_product_type;
	}
	public void setI_product_type(int i_product_type) {
		this.i_product_type = i_product_type;
	}
	public String getType_title() {
		return type_title;
	}
	public void setType_title(String type_title) {
		this.type_title = type_title;
	}
	
	

}
