var ttt= document.getElementById('.test')
if(ttt){
	console.log("있어")
}else(
	console.log("없어")
)