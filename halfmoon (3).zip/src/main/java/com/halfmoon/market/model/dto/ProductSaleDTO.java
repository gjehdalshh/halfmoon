package com.halfmoon.market.model.dto;

import com.halfmoon.market.model.ProductSaleEntity;

public class ProductSaleDTO extends ProductSaleEntity {
	
	private int toggle;

	public int getToggle() {
		return toggle;
	}

	public void setToggle(int toggle) {
		this.toggle = toggle;
	}
	
	
	
	

}
