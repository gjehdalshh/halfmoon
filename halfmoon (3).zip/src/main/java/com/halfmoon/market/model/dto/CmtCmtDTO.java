package com.halfmoon.market.model.dto;

import com.halfmoon.market.model.CmtCmtEntity;

public class CmtCmtDTO extends CmtCmtEntity {
}
