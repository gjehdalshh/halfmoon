package com.halfmoon.market.model;

public class ProductTypeSubEntity {
	
	private int i_product_type_sub;
	private int i_product_type;
	private String type_sub_title;
	
	public int getI_product_type_sub() {
		return i_product_type_sub;
	}
	public void setI_product_type_sub(int i_product_type_sub) {
		this.i_product_type_sub = i_product_type_sub;
	}
	public int getI_product_type() {
		return i_product_type;
	}
	public void setI_product_type(int i_product_type) {
		this.i_product_type = i_product_type;
	}
	public String getType_sub_title() {
		return type_sub_title;
	}
	public void setType_sub_title(String type_sub_title) {
		this.type_sub_title = type_sub_title;
	}
}
