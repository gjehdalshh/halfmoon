package com.halfmoon.market.model.dto;

import com.halfmoon.market.model.favoriteEntity;

public class FavoriteDTO extends favoriteEntity{

}
