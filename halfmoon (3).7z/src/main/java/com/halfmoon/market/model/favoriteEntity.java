package com.halfmoon.market.model;

public class favoriteEntity {
	
	private int i_user;
	private int i_product;
	
	public int getI_user() {
		return i_user;
	}
	public void setI_user(int i_user) {
		this.i_user = i_user;
	}
	public int getI_product() {
		return i_product;
	}
	public void setI_product(int i_product) {
		this.i_product = i_product;
	}
	
	
}
