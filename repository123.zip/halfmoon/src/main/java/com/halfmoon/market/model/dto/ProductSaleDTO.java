package com.halfmoon.market.model.dto;

import com.halfmoon.market.model.ProductSaleEntity;

public class ProductSaleDTO extends ProductSaleEntity {

}
