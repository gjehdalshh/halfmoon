package com.halfmoon.market.model.dto;

import com.halfmoon.market.model.ProductTypeSubEntity;

public class ProductTypeSubDTO extends ProductTypeSubEntity{

}
