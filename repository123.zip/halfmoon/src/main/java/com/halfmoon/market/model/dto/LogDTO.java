package com.halfmoon.market.model.dto;

import com.halfmoon.market.model.LogEntity;

public class LogDTO extends LogEntity {
}
