package com.halfmoon.market.model.dto;

import com.halfmoon.market.model.ProductBuyEntity;

public class ProductBuyDTO extends ProductBuyEntity {
}
