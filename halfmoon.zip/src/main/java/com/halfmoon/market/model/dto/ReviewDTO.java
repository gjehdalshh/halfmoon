package com.halfmoon.market.model.dto;

import com.halfmoon.market.model.ReviewEntity;

public class ReviewDTO extends ReviewEntity {

}
