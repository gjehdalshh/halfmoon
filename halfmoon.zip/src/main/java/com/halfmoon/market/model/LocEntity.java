package com.halfmoon.market.model;

public class LocEntity {
	
	private int i_loc;
	private String loc_nm;
	
	public int getI_loc() {
		return i_loc;
	}
	public void setI_loc(int i_loc) {
		this.i_loc = i_loc;
	}
	public String getLoc_nm() {
		return loc_nm;
	}
	public void setLoc_nm(String loc_nm) {
		this.loc_nm = loc_nm;
	}
}
