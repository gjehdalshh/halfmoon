package com.halfmoon.market.model.domain;

import com.halfmoon.market.model.LogEntity;

public class LogDomain extends LogEntity{
}
