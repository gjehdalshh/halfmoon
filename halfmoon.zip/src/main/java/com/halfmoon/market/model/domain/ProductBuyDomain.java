package com.halfmoon.market.model.domain;

import com.halfmoon.market.model.ProductBuyEntity;

public class ProductBuyDomain extends ProductBuyEntity {

}
